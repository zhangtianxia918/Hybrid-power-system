clc;clear;
Pload=load('pload.txt'); 
state=load('state.txt');
m = size(Pload, 1);

% Randomly select 720 data points to display
rand_indices = randperm(m);     % change the order -jin
rand_indices=rand_indices(1:720);
dd0=Pload(rand_indices,:)';

z=Pload;
z(rand_indices,:)=[];
b0=z';
state2=state(rand_indices,:);%tese data
state1=state;
state1(rand_indices,:)=[];   %train data
group=state1;

[b,ps]=mapstd(b0); %Standardization of train data
dd=mapstd('apply',dd0,ps); %Standardization of test data

option = statset('MaxIter',3000);
s= svmtrain( b', group, 'Kernel_Function', 'rbf', 'quadprog_opts', option ); 
beta=s.Alpha;
bb=s.Bias;
mean_and_std_trans=s.ScaleData; 
check=svmclassify(s,b'); 
err_rate=1-sum(group==check)/length(group);
solution=svmclassify(s,dd'); 
err_rate2=1-sum(state2==solution)/length(state2);
